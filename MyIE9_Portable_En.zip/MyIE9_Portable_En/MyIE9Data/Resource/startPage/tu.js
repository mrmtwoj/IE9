var g_openInNew=1;
var w_search=document.getElementById("word");
if(window.location.href.indexOf('?nofocus=1')==-1){if(window.attachEvent){window.attachEvent("onload",function(){document.getElementById("word").focus();})}};

function getmask(style,color,name,url)
{
	var openstr="window.open(\"" + url +"\")";
	if(0 == g_openInNew)
	{
		openstr="window.location.href=\"" + url +"\"";
	}
	
	return "<div onclick='"+openstr+"'  style=\"font-family:'黑体','Arial';\"><TABLE width=\"100%\" height=100% align=center border=0><TBODY><TR><TD height=90%  style=\"text-align:center;vertical-align:middle;"+style+";\" ><span onmouseover=\"this.style.cursor='hand'\"><FONT color=#"+color+" size=6>"+ name +"</FONT></span></TD></TR></TBODY></TABLE></div>";
}

function getmaskFlat(style,color,name,url)
{
	var openstr="window.open(\"" + url +"\")";
	if(0 == g_openInNew)
	{
		openstr="window.location.href=\"" + url +"\"";
	}
	
	return "<div onclick='"+openstr+"'  onmouseover=\"this.style.cursor='hand'\" style=\"font-family:'黑体','Arial'\" ><TABLE width=\"100%\" height=100% align=center border=0><TBODY><TR><TD height=100%  style=\"text-align:center;vertical-align:middle;\"><font style=\""+style+"\" onmouseover=\"this.style.cursor='hand'\"><strong>"+name +"</strong> </font></TD></TR></TBODY></TABLE></div>";
}

function getTu(pos,name,url)
{ 
	var arr = new Array(12);
	var style="filter:blur(direction=135,strength=10)";
	var color="000000";
	arr[0] = getmask(style,color,name,url);
	
	style="FILTER: mask(color=#E1E4EC)shadow(color=#000000,direction=135)chroma(color=#E1E4EC)";
	var color="000000";
	arr[1] = getmask(style,color,name,url);
	
	style="FILTER: glow(color=#8C96B5,=2)shadow(color=#B4BBCF,direction=135)";
	var color="000000";
	arr[8] = getmask(style,color,name,url);

	style="FILTER: glow(strength=1)mask(color=#B4BBCF)chroma(color=#B4BBCF)";
	var color="000000";
	arr[9] = getmask(style,color,name,url);
	
	style="FILTER: blur(direction=135,strength=8)";
	var color="000000";
	arr[4] = getmask(style,color,name,url);
	
	style="filter:shadow(color=#B4BBCF,direction=135)";
	var color="000000";
	arr[2] = getmask(style,color,name,url);
	
	style="filter:blur(direction=135,strength=10)";
	var color="000000";
	arr[5] = getmask(style,color,name,url);
	
	style="filter:alpha(opacity=100,finishiopacity=0,style=1)shadow(color=#8C96B5,direction=135)";
	var color="000000";
	arr[7] = getmask(style,color,name,url);
	
	style="filter:mask(color=#f7f7f7) shadow(color=royalblue,direction=135)";
	var color="000000";
	arr[6] = getmask(style,color,name,url);
	
	style="filter:glow(color=pink,strength=10)dropshadow(color=royalblue,offx=3,offy=3,positive=1)";
	var color="000000";
	arr[14] = getmask(style,color,name,url);
	
	style="filter:glow(color=green,strength=2)shadow(color=#66cc99 ,direction=135)";
	var color="000000";
	arr[10] = getmask(style,color,name,url);
	
	style="FILTER: dropshadow(color=#E99DFC,offx=30,offy=30,positive=1); FONT-FAMILY: 华文新魏";
	var color="000000";
	arr[15] = getmask(style,color,name,url);
	
	style="FONT-WEIGHT: bolder; FONT-SIZE: 26px; FILTER: blur(add=1, direction=45,strength=10); POSITION: relative";
	var color="000000";
	arr[12] = getmask(style,color,name,url);
	
	
	style="font-size: 26pt; filter: shadow(color=lime#000000);  color: 8C96B5";
	var color="";
	arr[13] = getmaskFlat(style,color,name,url);
	
	
	style="FONT-SIZE: 30pt; FILTER: shadow(color=black); COLOR: #000000; FONT-FAMILY: 华文彩云";
	var color="";
	arr[3] = getmaskFlat(style,color,name,url);
	
	style="FONT-WEIGHT: bolder; FONT-SIZE: 30px; FILTER: blur(add=1, direction=45,strength=10); POSITION: relative";
	var color="";
	arr[11] = getmaskFlat(style,color,name,url);
	
	
	var index=pos%16;	
	return arr[index];
}
